	<!--===============================================================================================-->
	<script src="<?= base_url('asset/login/vendor/jquery/jquery-3.2.1.min.js') ?>"></script>
	<!--===============================================================================================-->
	<script src="<?= base_url('asset/login/vendor/jquery/jquery-3.2.1.min.js') ?>"></script>
	<script src="<?= base_url('asset/login/vendor/bootstrap/js/bootstrap.min.js') ?>"></script>
	<!--===============================================================================================-->
	<script src="<?= base_url('asset/login/vendor/select2/select2.min.js') ?>"></script>
	<!--===============================================================================================-->
	<script src="<?= base_url('asset/login/vendor/tilt/tilt.jquery.min.js') ?>"></script>
	<script>
		$('.js-tilt').tilt({
			scale: 1.1
		})
	</script>
	<!--===============================================================================================-->
	<script src="<?= base_url('asset/login/js/main.js') ?>"></script>

	</body>

	</html>